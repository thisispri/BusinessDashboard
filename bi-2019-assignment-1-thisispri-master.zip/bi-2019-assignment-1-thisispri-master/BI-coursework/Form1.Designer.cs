﻿namespace BI_coursework
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend9 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend10 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title5 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblDimensionRegion = new System.Windows.Forms.Label();
            this.listboxRegionDimension = new System.Windows.Forms.ListBox();
            this.lblRegions = new System.Windows.Forms.Label();
            this.listboxRegion = new System.Windows.Forms.ListBox();
            this.lblDimensionDates = new System.Windows.Forms.Label();
            this.lblFactTable = new System.Windows.Forms.Label();
            this.lblGetProgress = new System.Windows.Forms.Label();
            this.lblBuildProgress = new System.Windows.Forms.Label();
            this.listBoxFactTable = new System.Windows.Forms.ListBox();
            this.listBoxDatesDimension = new System.Windows.Forms.ListBox();
            this.lblSourceDates = new System.Windows.Forms.Label();
            this.lblDestinationProgress = new System.Windows.Forms.Label();
            this.lblDimensionCustomers = new System.Windows.Forms.Label();
            this.lblDimensionProducts = new System.Windows.Forms.Label();
            this.lblDimensions = new System.Windows.Forms.Label();
            this.lblSourceCustomers = new System.Windows.Forms.Label();
            this.lblSourceProducts = new System.Windows.Forms.Label();
            this.lblSource = new System.Windows.Forms.Label();
            this.listBoxDates = new System.Windows.Forms.ListBox();
            this.lblSourceProgress = new System.Windows.Forms.Label();
            this.btnGetDataFromSource = new System.Windows.Forms.Button();
            this.listBoxCustomersDimension = new System.Windows.Forms.ListBox();
            this.listBoxCustomers = new System.Windows.Forms.ListBox();
            this.listBoxProductsDimension = new System.Windows.Forms.ListBox();
            this.listBoxProducts = new System.Windows.Forms.ListBox();
            this.tbProductDashboard = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chartProductByDate = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartMostValuableProducts = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartMostProfitableProducts = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dtpProductEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpProductStart = new System.Windows.Forms.DateTimePicker();
            this.btnLoadProductData = new System.Windows.Forms.Button();
            this.tabCustomerDashboard = new System.Windows.Forms.TabPage();
            this.lblCustomerSelectDate = new System.Windows.Forms.Label();
            this.lblCustomerAmount = new System.Windows.Forms.Label();
            this.lblCustomersWithMostDiscounts = new System.Windows.Forms.Label();
            this.lblProfitOnDate = new System.Windows.Forms.Label();
            this.chartProfitOnDate = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartCustomersWithMostDiscounts = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.numericUpDownCustomer = new System.Windows.Forms.NumericUpDown();
            this.monthCalendarCustomer = new System.Windows.Forms.MonthCalendar();
            this.lblMostProfitableCustomers = new System.Windows.Forms.Label();
            this.lblActiveCustomersByDate = new System.Windows.Forms.Label();
            this.chartMostProfitableCustomers = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartActiveCustomersByDate = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLoadCustomerData = new System.Windows.Forms.Button();
            this.tbRegionDashboard = new System.Windows.Forms.TabPage();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.crtRegionSales = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLoadData = new System.Windows.Forms.Button();
            this.tbDateDashboard = new System.Windows.Forms.TabPage();
            this.datechart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.datechart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLoadDateData = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tbProductDashboard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartProductByDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMostValuableProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMostProfitableProducts)).BeginInit();
            this.tabCustomerDashboard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartProfitOnDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartCustomersWithMostDiscounts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMostProfitableCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartActiveCustomersByDate)).BeginInit();
            this.tbRegionDashboard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.crtRegionSales)).BeginInit();
            this.tbDateDashboard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datechart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datechart2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tbProductDashboard);
            this.tabControl1.Controls.Add(this.tabCustomerDashboard);
            this.tabControl1.Controls.Add(this.tbRegionDashboard);
            this.tabControl1.Controls.Add(this.tbDateDashboard);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(759, 641);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblDimensionRegion);
            this.tabPage1.Controls.Add(this.listboxRegionDimension);
            this.tabPage1.Controls.Add(this.lblRegions);
            this.tabPage1.Controls.Add(this.listboxRegion);
            this.tabPage1.Controls.Add(this.lblDimensionDates);
            this.tabPage1.Controls.Add(this.lblFactTable);
            this.tabPage1.Controls.Add(this.lblGetProgress);
            this.tabPage1.Controls.Add(this.lblBuildProgress);
            this.tabPage1.Controls.Add(this.listBoxFactTable);
            this.tabPage1.Controls.Add(this.listBoxDatesDimension);
            this.tabPage1.Controls.Add(this.lblSourceDates);
            this.tabPage1.Controls.Add(this.lblDestinationProgress);
            this.tabPage1.Controls.Add(this.lblDimensionCustomers);
            this.tabPage1.Controls.Add(this.lblDimensionProducts);
            this.tabPage1.Controls.Add(this.lblDimensions);
            this.tabPage1.Controls.Add(this.lblSourceCustomers);
            this.tabPage1.Controls.Add(this.lblSourceProducts);
            this.tabPage1.Controls.Add(this.lblSource);
            this.tabPage1.Controls.Add(this.listBoxDates);
            this.tabPage1.Controls.Add(this.lblSourceProgress);
            this.tabPage1.Controls.Add(this.btnGetDataFromSource);
            this.tabPage1.Controls.Add(this.listBoxCustomersDimension);
            this.tabPage1.Controls.Add(this.listBoxCustomers);
            this.tabPage1.Controls.Add(this.listBoxProductsDimension);
            this.tabPage1.Controls.Add(this.listBoxProducts);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(751, 615);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ETL";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblDimensionRegion
            // 
            this.lblDimensionRegion.AutoSize = true;
            this.lblDimensionRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDimensionRegion.Location = new System.Drawing.Point(564, 320);
            this.lblDimensionRegion.Name = "lblDimensionRegion";
            this.lblDimensionRegion.Size = new System.Drawing.Size(47, 15);
            this.lblDimensionRegion.TabIndex = 33;
            this.lblDimensionRegion.Text = "Region";
            // 
            // listboxRegionDimension
            // 
            this.listboxRegionDimension.FormattingEnabled = true;
            this.listboxRegionDimension.HorizontalScrollbar = true;
            this.listboxRegionDimension.Location = new System.Drawing.Point(564, 339);
            this.listboxRegionDimension.Name = "listboxRegionDimension";
            this.listboxRegionDimension.Size = new System.Drawing.Size(178, 121);
            this.listboxRegionDimension.TabIndex = 32;
            // 
            // lblRegions
            // 
            this.lblRegions.AutoSize = true;
            this.lblRegions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegions.Location = new System.Drawing.Point(564, 76);
            this.lblRegions.Name = "lblRegions";
            this.lblRegions.Size = new System.Drawing.Size(53, 15);
            this.lblRegions.TabIndex = 31;
            this.lblRegions.Text = "Regions";
            // 
            // listboxRegion
            // 
            this.listboxRegion.FormattingEnabled = true;
            this.listboxRegion.HorizontalScrollbar = true;
            this.listboxRegion.Location = new System.Drawing.Point(564, 93);
            this.listboxRegion.Name = "listboxRegion";
            this.listboxRegion.Size = new System.Drawing.Size(179, 121);
            this.listboxRegion.TabIndex = 29;
            // 
            // lblDimensionDates
            // 
            this.lblDimensionDates.AutoSize = true;
            this.lblDimensionDates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblDimensionDates.Location = new System.Drawing.Point(377, 319);
            this.lblDimensionDates.Name = "lblDimensionDates";
            this.lblDimensionDates.Size = new System.Drawing.Size(44, 16);
            this.lblDimensionDates.TabIndex = 28;
            this.lblDimensionDates.Text = "Dates";
            // 
            // lblFactTable
            // 
            this.lblFactTable.AutoSize = true;
            this.lblFactTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblFactTable.Location = new System.Drawing.Point(5, 494);
            this.lblFactTable.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFactTable.Name = "lblFactTable";
            this.lblFactTable.Size = new System.Drawing.Size(104, 24);
            this.lblFactTable.TabIndex = 27;
            this.lblFactTable.Text = "Fact Table:";
            // 
            // lblGetProgress
            // 
            this.lblGetProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.865546F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblGetProgress.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblGetProgress.Location = new System.Drawing.Point(113, 521);
            this.lblGetProgress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGetProgress.Name = "lblGetProgress";
            this.lblGetProgress.Size = new System.Drawing.Size(152, 27);
            this.lblGetProgress.TabIndex = 25;
            this.lblGetProgress.Text = "lblGetProgress";
            this.lblGetProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblGetProgress.Visible = false;
            // 
            // lblBuildProgress
            // 
            this.lblBuildProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.865546F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblBuildProgress.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblBuildProgress.Location = new System.Drawing.Point(113, 495);
            this.lblBuildProgress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBuildProgress.Name = "lblBuildProgress";
            this.lblBuildProgress.Size = new System.Drawing.Size(152, 27);
            this.lblBuildProgress.TabIndex = 24;
            this.lblBuildProgress.Text = "lblBuildProgress";
            this.lblBuildProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBuildProgress.Visible = false;
            // 
            // listBoxFactTable
            // 
            this.listBoxFactTable.FormattingEnabled = true;
            this.listBoxFactTable.HorizontalScrollbar = true;
            this.listBoxFactTable.Location = new System.Drawing.Point(380, 521);
            this.listBoxFactTable.Name = "listBoxFactTable";
            this.listBoxFactTable.Size = new System.Drawing.Size(362, 82);
            this.listBoxFactTable.TabIndex = 22;
            // 
            // listBoxDatesDimension
            // 
            this.listBoxDatesDimension.FormattingEnabled = true;
            this.listBoxDatesDimension.HorizontalScrollbar = true;
            this.listBoxDatesDimension.Location = new System.Drawing.Point(380, 339);
            this.listBoxDatesDimension.Name = "listBoxDatesDimension";
            this.listBoxDatesDimension.Size = new System.Drawing.Size(179, 121);
            this.listBoxDatesDimension.TabIndex = 21;
            // 
            // lblSourceDates
            // 
            this.lblSourceDates.AutoSize = true;
            this.lblSourceDates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblSourceDates.Location = new System.Drawing.Point(377, 74);
            this.lblSourceDates.Name = "lblSourceDates";
            this.lblSourceDates.Size = new System.Drawing.Size(44, 16);
            this.lblSourceDates.TabIndex = 19;
            this.lblSourceDates.Text = "Dates";
            // 
            // lblDestinationProgress
            // 
            this.lblDestinationProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.865546F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblDestinationProgress.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblDestinationProgress.Location = new System.Drawing.Point(123, 285);
            this.lblDestinationProgress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDestinationProgress.Name = "lblDestinationProgress";
            this.lblDestinationProgress.Size = new System.Drawing.Size(222, 27);
            this.lblDestinationProgress.TabIndex = 18;
            this.lblDestinationProgress.Text = "lblDestinationProgress";
            this.lblDestinationProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDestinationProgress.Visible = false;
            // 
            // lblDimensionCustomers
            // 
            this.lblDimensionCustomers.AutoSize = true;
            this.lblDimensionCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblDimensionCustomers.Location = new System.Drawing.Point(191, 319);
            this.lblDimensionCustomers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDimensionCustomers.Name = "lblDimensionCustomers";
            this.lblDimensionCustomers.Size = new System.Drawing.Size(75, 17);
            this.lblDimensionCustomers.TabIndex = 16;
            this.lblDimensionCustomers.Text = "Customers";
            // 
            // lblDimensionProducts
            // 
            this.lblDimensionProducts.AutoSize = true;
            this.lblDimensionProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblDimensionProducts.Location = new System.Drawing.Point(7, 319);
            this.lblDimensionProducts.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDimensionProducts.Name = "lblDimensionProducts";
            this.lblDimensionProducts.Size = new System.Drawing.Size(64, 17);
            this.lblDimensionProducts.TabIndex = 15;
            this.lblDimensionProducts.Text = "Products";
            // 
            // lblDimensions
            // 
            this.lblDimensions.AutoSize = true;
            this.lblDimensions.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblDimensions.Location = new System.Drawing.Point(5, 288);
            this.lblDimensions.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDimensions.Name = "lblDimensions";
            this.lblDimensions.Size = new System.Drawing.Size(114, 24);
            this.lblDimensions.TabIndex = 14;
            this.lblDimensions.Text = "Dimensions:";
            // 
            // lblSourceCustomers
            // 
            this.lblSourceCustomers.AutoSize = true;
            this.lblSourceCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblSourceCustomers.Location = new System.Drawing.Point(191, 74);
            this.lblSourceCustomers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSourceCustomers.Name = "lblSourceCustomers";
            this.lblSourceCustomers.Size = new System.Drawing.Size(75, 17);
            this.lblSourceCustomers.TabIndex = 13;
            this.lblSourceCustomers.Text = "Customers";
            // 
            // lblSourceProducts
            // 
            this.lblSourceProducts.AutoSize = true;
            this.lblSourceProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblSourceProducts.Location = new System.Drawing.Point(7, 74);
            this.lblSourceProducts.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSourceProducts.Name = "lblSourceProducts";
            this.lblSourceProducts.Size = new System.Drawing.Size(64, 17);
            this.lblSourceProducts.TabIndex = 12;
            this.lblSourceProducts.Text = "Products";
            // 
            // lblSource
            // 
            this.lblSource.AutoSize = true;
            this.lblSource.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblSource.Location = new System.Drawing.Point(5, 43);
            this.lblSource.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSource.Name = "lblSource";
            this.lblSource.Size = new System.Drawing.Size(76, 24);
            this.lblSource.TabIndex = 11;
            this.lblSource.Text = "Source:";
            // 
            // listBoxDates
            // 
            this.listBoxDates.FormattingEnabled = true;
            this.listBoxDates.HorizontalScrollbar = true;
            this.listBoxDates.Location = new System.Drawing.Point(380, 92);
            this.listBoxDates.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxDates.Name = "listBoxDates";
            this.listBoxDates.Size = new System.Drawing.Size(179, 121);
            this.listBoxDates.TabIndex = 17;
            // 
            // lblSourceProgress
            // 
            this.lblSourceProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.865546F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblSourceProgress.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblSourceProgress.Location = new System.Drawing.Point(232, 14);
            this.lblSourceProgress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSourceProgress.Name = "lblSourceProgress";
            this.lblSourceProgress.Size = new System.Drawing.Size(222, 27);
            this.lblSourceProgress.TabIndex = 10;
            this.lblSourceProgress.Text = "lblSourceProgress";
            this.lblSourceProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSourceProgress.Visible = false;
            // 
            // btnGetDataFromSource
            // 
            this.btnGetDataFromSource.Location = new System.Drawing.Point(5, 14);
            this.btnGetDataFromSource.Margin = new System.Windows.Forms.Padding(2);
            this.btnGetDataFromSource.Name = "btnGetDataFromSource";
            this.btnGetDataFromSource.Size = new System.Drawing.Size(222, 27);
            this.btnGetDataFromSource.TabIndex = 9;
            this.btnGetDataFromSource.Text = "Load Data";
            this.btnGetDataFromSource.UseVisualStyleBackColor = true;
            this.btnGetDataFromSource.Click += new System.EventHandler(this.btnGetDataFromSource_Click);
            // 
            // listBoxCustomersDimension
            // 
            this.listBoxCustomersDimension.FormattingEnabled = true;
            this.listBoxCustomersDimension.HorizontalScrollbar = true;
            this.listBoxCustomersDimension.Location = new System.Drawing.Point(194, 339);
            this.listBoxCustomersDimension.Name = "listBoxCustomersDimension";
            this.listBoxCustomersDimension.Size = new System.Drawing.Size(179, 121);
            this.listBoxCustomersDimension.TabIndex = 8;
            // 
            // listBoxCustomers
            // 
            this.listBoxCustomers.FormattingEnabled = true;
            this.listBoxCustomers.HorizontalScrollbar = true;
            this.listBoxCustomers.Location = new System.Drawing.Point(194, 93);
            this.listBoxCustomers.Name = "listBoxCustomers";
            this.listBoxCustomers.Size = new System.Drawing.Size(179, 121);
            this.listBoxCustomers.TabIndex = 6;
            // 
            // listBoxProductsDimension
            // 
            this.listBoxProductsDimension.FormattingEnabled = true;
            this.listBoxProductsDimension.HorizontalScrollbar = true;
            this.listBoxProductsDimension.Location = new System.Drawing.Point(10, 339);
            this.listBoxProductsDimension.Name = "listBoxProductsDimension";
            this.listBoxProductsDimension.Size = new System.Drawing.Size(179, 121);
            this.listBoxProductsDimension.TabIndex = 3;
            // 
            // listBoxProducts
            // 
            this.listBoxProducts.FormattingEnabled = true;
            this.listBoxProducts.HorizontalScrollbar = true;
            this.listBoxProducts.Location = new System.Drawing.Point(10, 93);
            this.listBoxProducts.Name = "listBoxProducts";
            this.listBoxProducts.Size = new System.Drawing.Size(179, 121);
            this.listBoxProducts.TabIndex = 1;
            // 
            // tbProductDashboard
            // 
            this.tbProductDashboard.Controls.Add(this.label2);
            this.tbProductDashboard.Controls.Add(this.label1);
            this.tbProductDashboard.Controls.Add(this.chartProductByDate);
            this.tbProductDashboard.Controls.Add(this.chartMostValuableProducts);
            this.tbProductDashboard.Controls.Add(this.chartMostProfitableProducts);
            this.tbProductDashboard.Controls.Add(this.dtpProductEnd);
            this.tbProductDashboard.Controls.Add(this.dtpProductStart);
            this.tbProductDashboard.Controls.Add(this.btnLoadProductData);
            this.tbProductDashboard.Location = new System.Drawing.Point(4, 22);
            this.tbProductDashboard.Name = "tbProductDashboard";
            this.tbProductDashboard.Padding = new System.Windows.Forms.Padding(3);
            this.tbProductDashboard.Size = new System.Drawing.Size(751, 615);
            this.tbProductDashboard.TabIndex = 1;
            this.tbProductDashboard.Text = "Product Dashboard";
            this.tbProductDashboard.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-4, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Profit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(332, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Profit";
            // 
            // chartProductByDate
            // 
            chartArea1.Name = "ChartArea1";
            this.chartProductByDate.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartProductByDate.Legends.Add(legend1);
            this.chartProductByDate.Location = new System.Drawing.Point(8, 341);
            this.chartProductByDate.Name = "chartProductByDate";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartProductByDate.Series.Add(series1);
            this.chartProductByDate.Size = new System.Drawing.Size(735, 271);
            this.chartProductByDate.TabIndex = 6;
            this.chartProductByDate.Text = "chart1";
            title1.BackColor = System.Drawing.Color.DodgerBlue;
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            title1.Name = "Title";
            title1.Text = "Profit of Product By Date";
            this.chartProductByDate.Titles.Add(title1);
            // 
            // chartMostValuableProducts
            // 
            chartArea2.Name = "ChartArea1";
            this.chartMostValuableProducts.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartMostValuableProducts.Legends.Add(legend2);
            this.chartMostValuableProducts.Location = new System.Drawing.Point(363, 88);
            this.chartMostValuableProducts.Name = "chartMostValuableProducts";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartMostValuableProducts.Series.Add(series2);
            this.chartMostValuableProducts.Size = new System.Drawing.Size(385, 242);
            this.chartMostValuableProducts.TabIndex = 5;
            this.chartMostValuableProducts.Text = "chart1";
            title2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            title2.Name = "Title1";
            title2.Text = "Product by Value";
            this.chartMostValuableProducts.Titles.Add(title2);
            // 
            // chartMostProfitableProducts
            // 
            chartArea3.Name = "ChartArea1";
            this.chartMostProfitableProducts.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chartMostProfitableProducts.Legends.Add(legend3);
            this.chartMostProfitableProducts.Location = new System.Drawing.Point(3, 88);
            this.chartMostProfitableProducts.Name = "chartMostProfitableProducts";
            series3.ChartArea = "ChartArea1";
            series3.Color = System.Drawing.Color.MediumAquamarine;
            series3.Legend = "Legend1";
            series3.Name = "Profit";
            this.chartMostProfitableProducts.Series.Add(series3);
            this.chartMostProfitableProducts.Size = new System.Drawing.Size(365, 247);
            this.chartMostProfitableProducts.TabIndex = 3;
            this.chartMostProfitableProducts.Text = "chartMostProfitableProducts";
            title3.BackColor = System.Drawing.Color.MediumAquamarine;
            title3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            title3.Name = "Title1";
            title3.Text = "Product by Profit";
            this.chartMostProfitableProducts.Titles.Add(title3);
            // 
            // dtpProductEnd
            // 
            this.dtpProductEnd.Location = new System.Drawing.Point(456, 32);
            this.dtpProductEnd.Name = "dtpProductEnd";
            this.dtpProductEnd.Size = new System.Drawing.Size(200, 20);
            this.dtpProductEnd.TabIndex = 2;
            this.dtpProductEnd.Value = new System.DateTime(2014, 1, 30, 20, 10, 0, 0);
            // 
            // dtpProductStart
            // 
            this.dtpProductStart.Location = new System.Drawing.Point(168, 32);
            this.dtpProductStart.Name = "dtpProductStart";
            this.dtpProductStart.Size = new System.Drawing.Size(200, 20);
            this.dtpProductStart.TabIndex = 1;
            this.dtpProductStart.Value = new System.DateTime(2014, 1, 1, 20, 10, 0, 0);
            // 
            // btnLoadProductData
            // 
            this.btnLoadProductData.Location = new System.Drawing.Point(8, 15);
            this.btnLoadProductData.Name = "btnLoadProductData";
            this.btnLoadProductData.Size = new System.Drawing.Size(126, 37);
            this.btnLoadProductData.TabIndex = 0;
            this.btnLoadProductData.Text = "Load Data";
            this.btnLoadProductData.UseVisualStyleBackColor = true;
            this.btnLoadProductData.Click += new System.EventHandler(this.btnLoadProductData_Click);
            // 
            // tabCustomerDashboard
            // 
            this.tabCustomerDashboard.Controls.Add(this.lblCustomerSelectDate);
            this.tabCustomerDashboard.Controls.Add(this.lblCustomerAmount);
            this.tabCustomerDashboard.Controls.Add(this.lblCustomersWithMostDiscounts);
            this.tabCustomerDashboard.Controls.Add(this.lblProfitOnDate);
            this.tabCustomerDashboard.Controls.Add(this.chartProfitOnDate);
            this.tabCustomerDashboard.Controls.Add(this.chartCustomersWithMostDiscounts);
            this.tabCustomerDashboard.Controls.Add(this.numericUpDownCustomer);
            this.tabCustomerDashboard.Controls.Add(this.monthCalendarCustomer);
            this.tabCustomerDashboard.Controls.Add(this.lblMostProfitableCustomers);
            this.tabCustomerDashboard.Controls.Add(this.lblActiveCustomersByDate);
            this.tabCustomerDashboard.Controls.Add(this.chartMostProfitableCustomers);
            this.tabCustomerDashboard.Controls.Add(this.chartActiveCustomersByDate);
            this.tabCustomerDashboard.Controls.Add(this.btnLoadCustomerData);
            this.tabCustomerDashboard.Location = new System.Drawing.Point(4, 22);
            this.tabCustomerDashboard.Name = "tabCustomerDashboard";
            this.tabCustomerDashboard.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomerDashboard.Size = new System.Drawing.Size(751, 615);
            this.tabCustomerDashboard.TabIndex = 2;
            this.tabCustomerDashboard.Text = "Customer Dashboard";
            this.tabCustomerDashboard.UseVisualStyleBackColor = true;
            // 
            // lblCustomerSelectDate
            // 
            this.lblCustomerSelectDate.Location = new System.Drawing.Point(8, 58);
            this.lblCustomerSelectDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCustomerSelectDate.Name = "lblCustomerSelectDate";
            this.lblCustomerSelectDate.Size = new System.Drawing.Size(154, 19);
            this.lblCustomerSelectDate.TabIndex = 24;
            this.lblCustomerSelectDate.Text = "Hold to select a period:";
            this.lblCustomerSelectDate.Visible = false;
            // 
            // lblCustomerAmount
            // 
            this.lblCustomerAmount.Location = new System.Drawing.Point(8, 254);
            this.lblCustomerAmount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCustomerAmount.Name = "lblCustomerAmount";
            this.lblCustomerAmount.Size = new System.Drawing.Size(154, 19);
            this.lblCustomerAmount.TabIndex = 23;
            this.lblCustomerAmount.Text = "Customer amount:";
            this.lblCustomerAmount.Visible = false;
            // 
            // lblCustomersWithMostDiscounts
            // 
            this.lblCustomersWithMostDiscounts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCustomersWithMostDiscounts.BackColor = System.Drawing.Color.Khaki;
            this.lblCustomersWithMostDiscounts.Location = new System.Drawing.Point(449, 6);
            this.lblCustomersWithMostDiscounts.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCustomersWithMostDiscounts.Name = "lblCustomersWithMostDiscounts";
            this.lblCustomersWithMostDiscounts.Size = new System.Drawing.Size(301, 28);
            this.lblCustomersWithMostDiscounts.TabIndex = 22;
            this.lblCustomersWithMostDiscounts.Text = "Customers With Most Discounts";
            this.lblCustomersWithMostDiscounts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCustomersWithMostDiscounts.Visible = false;
            // 
            // lblProfitOnDate
            // 
            this.lblProfitOnDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblProfitOnDate.BackColor = System.Drawing.Color.Khaki;
            this.lblProfitOnDate.Location = new System.Drawing.Point(8, 307);
            this.lblProfitOnDate.Name = "lblProfitOnDate";
            this.lblProfitOnDate.Size = new System.Drawing.Size(742, 28);
            this.lblProfitOnDate.TabIndex = 21;
            this.lblProfitOnDate.Text = "Profit On Date";
            this.lblProfitOnDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblProfitOnDate.Visible = false;
            // 
            // chartProfitOnDate
            // 
            this.chartProfitOnDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartProfitOnDate.BorderlineColor = System.Drawing.Color.Khaki;
            this.chartProfitOnDate.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea4.AxisX.Interval = 1D;
            chartArea4.AxisX.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea4.AxisY.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea4.AxisY.Title = "Profit";
            chartArea4.Name = "ChartArea1";
            this.chartProfitOnDate.ChartAreas.Add(chartArea4);
            legend4.Enabled = false;
            legend4.Name = "Legend1";
            this.chartProfitOnDate.Legends.Add(legend4);
            this.chartProfitOnDate.Location = new System.Drawing.Point(8, 336);
            this.chartProfitOnDate.Name = "chartProfitOnDate";
            this.chartProfitOnDate.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Light;
            series4.BorderWidth = 2;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Color = System.Drawing.Color.Black;
            series4.Label = "#VAL";
            series4.LabelForeColor = System.Drawing.Color.Green;
            series4.Legend = "Legend1";
            series4.Name = "Profit";
            series4.YValuesPerPoint = 4;
            this.chartProfitOnDate.Series.Add(series4);
            this.chartProfitOnDate.Size = new System.Drawing.Size(742, 124);
            this.chartProfitOnDate.TabIndex = 19;
            this.chartProfitOnDate.Text = "Profit On Date";
            this.chartProfitOnDate.Visible = false;
            // 
            // chartCustomersWithMostDiscounts
            // 
            this.chartCustomersWithMostDiscounts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chartCustomersWithMostDiscounts.BorderlineColor = System.Drawing.Color.Khaki;
            this.chartCustomersWithMostDiscounts.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea5.AxisX.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea5.AxisY.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea5.Name = "ChartArea1";
            this.chartCustomersWithMostDiscounts.ChartAreas.Add(chartArea5);
            legend5.Enabled = false;
            legend5.Name = "Legend1";
            this.chartCustomersWithMostDiscounts.Legends.Add(legend5);
            this.chartCustomersWithMostDiscounts.Location = new System.Drawing.Point(449, 35);
            this.chartCustomersWithMostDiscounts.Margin = new System.Windows.Forms.Padding(2);
            this.chartCustomersWithMostDiscounts.Name = "chartCustomersWithMostDiscounts";
            series5.ChartArea = "ChartArea1";
            series5.Label = "#VAL";
            series5.Legend = "Legend1";
            series5.Name = "Discount";
            series5.YValuesPerPoint = 4;
            this.chartCustomersWithMostDiscounts.Series.Add(series5);
            this.chartCustomersWithMostDiscounts.Size = new System.Drawing.Size(301, 269);
            this.chartCustomersWithMostDiscounts.TabIndex = 18;
            this.chartCustomersWithMostDiscounts.Text = "Customers With Most Discounts";
            this.chartCustomersWithMostDiscounts.Visible = false;
            // 
            // numericUpDownCustomer
            // 
            this.numericUpDownCustomer.Location = new System.Drawing.Point(8, 275);
            this.numericUpDownCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDownCustomer.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownCustomer.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCustomer.Name = "numericUpDownCustomer";
            this.numericUpDownCustomer.Size = new System.Drawing.Size(196, 20);
            this.numericUpDownCustomer.TabIndex = 17;
            this.numericUpDownCustomer.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDownCustomer.Visible = false;
            this.numericUpDownCustomer.ValueChanged += new System.EventHandler(this.numericUpDownCustomer_ValueChanged);
            // 
            // monthCalendarCustomer
            // 
            this.monthCalendarCustomer.Location = new System.Drawing.Point(8, 77);
            this.monthCalendarCustomer.MaxSelectionCount = 31;
            this.monthCalendarCustomer.Name = "monthCalendarCustomer";
            this.monthCalendarCustomer.SelectionRange = new System.Windows.Forms.SelectionRange(new System.DateTime(2014, 1, 1, 0, 0, 0, 0), new System.DateTime(2014, 1, 31, 0, 0, 0, 0));
            this.monthCalendarCustomer.TabIndex = 14;
            this.monthCalendarCustomer.TodayDate = new System.DateTime(2014, 1, 1, 0, 0, 0, 0);
            this.monthCalendarCustomer.Visible = false;
            this.monthCalendarCustomer.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendarCustomer_DateSelected);
            // 
            // lblMostProfitableCustomers
            // 
            this.lblMostProfitableCustomers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMostProfitableCustomers.BackColor = System.Drawing.Color.Khaki;
            this.lblMostProfitableCustomers.Location = new System.Drawing.Point(216, 6);
            this.lblMostProfitableCustomers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMostProfitableCustomers.Name = "lblMostProfitableCustomers";
            this.lblMostProfitableCustomers.Size = new System.Drawing.Size(229, 28);
            this.lblMostProfitableCustomers.TabIndex = 13;
            this.lblMostProfitableCustomers.Text = "Most Profitable Customers";
            this.lblMostProfitableCustomers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMostProfitableCustomers.Visible = false;
            // 
            // lblActiveCustomersByDate
            // 
            this.lblActiveCustomersByDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblActiveCustomersByDate.BackColor = System.Drawing.Color.Khaki;
            this.lblActiveCustomersByDate.Location = new System.Drawing.Point(8, 463);
            this.lblActiveCustomersByDate.Name = "lblActiveCustomersByDate";
            this.lblActiveCustomersByDate.Size = new System.Drawing.Size(742, 28);
            this.lblActiveCustomersByDate.TabIndex = 12;
            this.lblActiveCustomersByDate.Text = "Active Customers By Date";
            this.lblActiveCustomersByDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblActiveCustomersByDate.Visible = false;
            // 
            // chartMostProfitableCustomers
            // 
            this.chartMostProfitableCustomers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartMostProfitableCustomers.BorderlineColor = System.Drawing.Color.Khaki;
            this.chartMostProfitableCustomers.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea6.AxisX.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea6.AxisY.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea6.Name = "ChartArea1";
            this.chartMostProfitableCustomers.ChartAreas.Add(chartArea6);
            legend6.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend6.Name = "Legend1";
            this.chartMostProfitableCustomers.Legends.Add(legend6);
            this.chartMostProfitableCustomers.Location = new System.Drawing.Point(216, 35);
            this.chartMostProfitableCustomers.Margin = new System.Windows.Forms.Padding(2);
            this.chartMostProfitableCustomers.Name = "chartMostProfitableCustomers";
            series6.ChartArea = "ChartArea1";
            series6.Label = "#VAL";
            series6.Legend = "Legend1";
            series6.Name = "Profit";
            series6.YValuesPerPoint = 4;
            series7.ChartArea = "ChartArea1";
            series7.Label = "#VAL";
            series7.Legend = "Legend1";
            series7.Name = "Value";
            this.chartMostProfitableCustomers.Series.Add(series6);
            this.chartMostProfitableCustomers.Series.Add(series7);
            this.chartMostProfitableCustomers.Size = new System.Drawing.Size(229, 269);
            this.chartMostProfitableCustomers.TabIndex = 2;
            this.chartMostProfitableCustomers.Text = "Most Profitable Customers";
            this.chartMostProfitableCustomers.Visible = false;
            // 
            // chartActiveCustomersByDate
            // 
            this.chartActiveCustomersByDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartActiveCustomersByDate.BorderlineColor = System.Drawing.Color.Khaki;
            this.chartActiveCustomersByDate.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea7.AxisX.Interval = 1D;
            chartArea7.AxisX.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea7.AxisY.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea7.AxisY.Title = "Customers";
            chartArea7.Name = "ChartArea1";
            this.chartActiveCustomersByDate.ChartAreas.Add(chartArea7);
            legend7.Enabled = false;
            legend7.Name = "Legend1";
            this.chartActiveCustomersByDate.Legends.Add(legend7);
            this.chartActiveCustomersByDate.Location = new System.Drawing.Point(8, 492);
            this.chartActiveCustomersByDate.Name = "chartActiveCustomersByDate";
            this.chartActiveCustomersByDate.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Light;
            series8.BorderWidth = 2;
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series8.Color = System.Drawing.Color.Purple;
            series8.Legend = "Legend1";
            series8.Name = "Customers";
            series8.YValuesPerPoint = 4;
            this.chartActiveCustomersByDate.Series.Add(series8);
            this.chartActiveCustomersByDate.Size = new System.Drawing.Size(742, 122);
            this.chartActiveCustomersByDate.TabIndex = 2;
            this.chartActiveCustomersByDate.Text = "Active Customers By Date";
            this.chartActiveCustomersByDate.Visible = false;
            // 
            // btnLoadCustomerData
            // 
            this.btnLoadCustomerData.Location = new System.Drawing.Point(8, 6);
            this.btnLoadCustomerData.Margin = new System.Windows.Forms.Padding(2);
            this.btnLoadCustomerData.Name = "btnLoadCustomerData";
            this.btnLoadCustomerData.Size = new System.Drawing.Size(196, 42);
            this.btnLoadCustomerData.TabIndex = 0;
            this.btnLoadCustomerData.Text = "Load Data";
            this.btnLoadCustomerData.UseVisualStyleBackColor = true;
            this.btnLoadCustomerData.Click += new System.EventHandler(this.btnLoadCustomerData_Click);
            // 
            // tbRegionDashboard
            // 
            this.tbRegionDashboard.Controls.Add(this.dtpEndDate);
            this.tbRegionDashboard.Controls.Add(this.dtpStartDate);
            this.tbRegionDashboard.Controls.Add(this.crtRegionSales);
            this.tbRegionDashboard.Controls.Add(this.btnLoadData);
            this.tbRegionDashboard.Location = new System.Drawing.Point(4, 22);
            this.tbRegionDashboard.Name = "tbRegionDashboard";
            this.tbRegionDashboard.Size = new System.Drawing.Size(751, 615);
            this.tbRegionDashboard.TabIndex = 3;
            this.tbRegionDashboard.Text = "Region Dashbaord";
            this.tbRegionDashboard.UseVisualStyleBackColor = true;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Location = new System.Drawing.Point(322, 25);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(200, 20);
            this.dtpEndDate.TabIndex = 3;
            this.dtpEndDate.Value = new System.DateTime(2014, 1, 31, 0, 0, 0, 0);
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(116, 25);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 2;
            this.dtpStartDate.Value = new System.DateTime(2014, 1, 1, 0, 0, 0, 0);
            // 
            // crtRegionSales
            // 
            chartArea8.Name = "Most Profitable Region";
            this.crtRegionSales.ChartAreas.Add(chartArea8);
            legend8.Name = "Legend1";
            this.crtRegionSales.Legends.Add(legend8);
            this.crtRegionSales.Location = new System.Drawing.Point(8, 66);
            this.crtRegionSales.Name = "crtRegionSales";
            this.crtRegionSales.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series9.ChartArea = "Most Profitable Region";
            series9.Legend = "Legend1";
            series9.Name = "Profit";
            this.crtRegionSales.Series.Add(series9);
            this.crtRegionSales.Size = new System.Drawing.Size(735, 354);
            this.crtRegionSales.TabIndex = 1;
            this.crtRegionSales.Text = "Most Sales Per Region";
            title4.BackColor = System.Drawing.Color.DarkGreen;
            title4.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title4.ForeColor = System.Drawing.Color.White;
            title4.Name = "Title1";
            title4.Text = "Most Profitable Regions";
            this.crtRegionSales.Titles.Add(title4);
            // 
            // btnLoadData
            // 
            this.btnLoadData.Location = new System.Drawing.Point(8, 15);
            this.btnLoadData.Name = "btnLoadData";
            this.btnLoadData.Size = new System.Drawing.Size(102, 45);
            this.btnLoadData.TabIndex = 0;
            this.btnLoadData.Text = "Load Data";
            this.btnLoadData.UseVisualStyleBackColor = true;
            this.btnLoadData.Click += new System.EventHandler(this.btnLoadData_Click);
            // 
            // tbDateDashboard
            // 
            this.tbDateDashboard.Controls.Add(this.datechart1);
            this.tbDateDashboard.Controls.Add(this.datechart2);
            this.tbDateDashboard.Controls.Add(this.btnLoadDateData);
            this.tbDateDashboard.Location = new System.Drawing.Point(4, 22);
            this.tbDateDashboard.Name = "tbDateDashboard";
            this.tbDateDashboard.Padding = new System.Windows.Forms.Padding(3);
            this.tbDateDashboard.Size = new System.Drawing.Size(751, 615);
            this.tbDateDashboard.TabIndex = 4;
            this.tbDateDashboard.Text = "Date Dashboard (Labs)";
            this.tbDateDashboard.UseVisualStyleBackColor = true;
            // 
            // datechart1
            // 
            chartArea9.Name = "ChartArea1";
            this.datechart1.ChartAreas.Add(chartArea9);
            legend9.Name = "Legend1";
            this.datechart1.Legends.Add(legend9);
            this.datechart1.Location = new System.Drawing.Point(32, 133);
            this.datechart1.Name = "datechart1";
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series10.Legend = "Legend1";
            series10.Name = "Series1";
            this.datechart1.Series.Add(series10);
            this.datechart1.Size = new System.Drawing.Size(360, 342);
            this.datechart1.TabIndex = 2;
            this.datechart1.Text = "chart4";
            // 
            // datechart2
            // 
            chartArea10.AxisY.Title = "Sales";
            chartArea10.Name = "ChartArea1";
            this.datechart2.ChartAreas.Add(chartArea10);
            legend10.Name = "Legend1";
            this.datechart2.Legends.Add(legend10);
            this.datechart2.Location = new System.Drawing.Point(409, 133);
            this.datechart2.Name = "datechart2";
            series11.ChartArea = "ChartArea1";
            series11.Legend = "Legend1";
            series11.Name = "Sales";
            this.datechart2.Series.Add(series11);
            this.datechart2.Size = new System.Drawing.Size(324, 342);
            this.datechart2.TabIndex = 1;
            this.datechart2.Text = "chart3";
            title5.Name = "Number of sales";
            this.datechart2.Titles.Add(title5);
            this.datechart2.Visible = false;
            // 
            // btnLoadDateData
            // 
            this.btnLoadDateData.Location = new System.Drawing.Point(6, 6);
            this.btnLoadDateData.Name = "btnLoadDateData";
            this.btnLoadDateData.Size = new System.Drawing.Size(109, 38);
            this.btnLoadDateData.TabIndex = 0;
            this.btnLoadDateData.Text = "Load Data";
            this.btnLoadDateData.UseVisualStyleBackColor = true;
            this.btnLoadDateData.Click += new System.EventHandler(this.btnLoadDateData_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 641);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ETL";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tbProductDashboard.ResumeLayout(false);
            this.tbProductDashboard.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartProductByDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMostValuableProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMostProfitableProducts)).EndInit();
            this.tabCustomerDashboard.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartProfitOnDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartCustomersWithMostDiscounts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMostProfitableCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartActiveCustomersByDate)).EndInit();
            this.tbRegionDashboard.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.crtRegionSales)).EndInit();
            this.tbDateDashboard.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datechart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datechart2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tbProductDashboard;
        private System.Windows.Forms.TabPage tabCustomerDashboard;
        private System.Windows.Forms.TabPage tbRegionDashboard;
        private System.Windows.Forms.ListBox listBoxProducts;
        private System.Windows.Forms.ListBox listBoxProductsDimension;
        private System.Windows.Forms.ListBox listBoxCustomersDimension;
        private System.Windows.Forms.ListBox listBoxCustomers;
        private System.Windows.Forms.Button btnGetDataFromSource;
        private System.Windows.Forms.Label lblSourceProgress;
        private System.Windows.Forms.Label lblSourceCustomers;
        private System.Windows.Forms.Label lblSourceProducts;
        private System.Windows.Forms.Label lblSource;
        private System.Windows.Forms.Label lblDimensions;
        private System.Windows.Forms.Label lblDimensionCustomers;
        private System.Windows.Forms.Label lblDimensionProducts;
        private System.Windows.Forms.Label lblDestinationProgress;
        private System.Windows.Forms.ListBox listBoxDates;
        private System.Windows.Forms.Label lblSourceDates;
        private System.Windows.Forms.ListBox listBoxDatesDimension;
        private System.Windows.Forms.ListBox listBoxFactTable;
        private System.Windows.Forms.Label lblGetProgress;
        private System.Windows.Forms.Label lblBuildProgress;
        private System.Windows.Forms.Label lblFactTable;
        private System.Windows.Forms.Label lblDimensionDates;
        private System.Windows.Forms.Label lblRegions;
        private System.Windows.Forms.ListBox listboxRegion;
        private System.Windows.Forms.Label lblDimensionRegion;
        private System.Windows.Forms.ListBox listboxRegionDimension;
        private System.Windows.Forms.Button btnLoadCustomerData;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMostProfitableCustomers;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartActiveCustomersByDate;
        private System.Windows.Forms.Label lblActiveCustomersByDate;
        private System.Windows.Forms.Label lblMostProfitableCustomers;
        private System.Windows.Forms.Button btnLoadProductData;
        private System.Windows.Forms.TabPage tbDateDashboard;
        private System.Windows.Forms.Button btnLoadDateData;
        private System.Windows.Forms.DataVisualization.Charting.Chart datechart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart datechart2;
        private System.Windows.Forms.MonthCalendar monthCalendarCustomer;
        private System.Windows.Forms.NumericUpDown numericUpDownCustomer;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartProfitOnDate;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartCustomersWithMostDiscounts;
        private System.Windows.Forms.Label lblProfitOnDate;
        private System.Windows.Forms.Label lblCustomersWithMostDiscounts;
        private System.Windows.Forms.Label lblCustomerAmount;
        private System.Windows.Forms.DateTimePicker dtpProductEnd;
        private System.Windows.Forms.DateTimePicker dtpProductStart;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMostProfitableProducts;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMostValuableProducts;
        private System.Windows.Forms.Label lblCustomerSelectDate;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartProductByDate;
        private System.Windows.Forms.Button btnLoadData;
        private System.Windows.Forms.DataVisualization.Charting.Chart crtRegionSales;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}